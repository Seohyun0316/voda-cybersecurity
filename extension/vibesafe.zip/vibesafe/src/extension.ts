/**
 * VibeSafe 진입점 — 모든 모듈을 조립한다.
 *
 * 흐름: 문서 열림/수정 → (debounce) → analyzer.analyze()
 *      → diagnostics + 사이드 패널 + 상태바 + quick fix 캐시 갱신
 */
import * as vscode from 'vscode';
import { createAnalyzer, Analyzer } from './analyzer';
import { DiagnosticsManager } from './diagnostics';
import { RiskPanelProvider } from './riskPanel';
import { StatusBarManager } from './statusBar';
import { VibeSafeCodeActionProvider, applyAllFixes } from './codeActions';

/** 분석 대상 언어 */
const SUPPORTED = new Set(['python', 'javascript', 'typescript', 'javascriptreact', 'typescriptreact', 'java', 'go', 'php', 'ruby']);

export function activate(context: vscode.ExtensionContext): void {
  let analyzer: Analyzer = createAnalyzer();
  const diagnostics = new DiagnosticsManager(context);
  const statusBar = new StatusBarManager(context);
  const codeActions = new VibeSafeCodeActionProvider();
  const panel = new RiskPanelProvider(() => applyAllFixes(panel.getLastResult()));

  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(RiskPanelProvider.viewId, panel),
    vscode.languages.registerCodeActionsProvider(
      [...SUPPORTED].map((language) => ({ language })),
      codeActions,
      VibeSafeCodeActionProvider.metadata,
    ),
  );

  async function analyzeDocument(doc: vscode.TextDocument): Promise<void> {
    if (!SUPPORTED.has(doc.languageId)) return;
    try {
      const result = await analyzer.analyze(doc.getText(), doc.fileName, doc.languageId);
      diagnostics.update(doc.uri, result);
      codeActions.setResult(doc.uri, result);
      statusBar.update(result);
      panel.update(result);
    } catch (err) {
      // 원격 엔진 실패 시 사용자에게 알리고 로컬 규칙으로 폴백
      vscode.window.showWarningMessage(
        `VibeSafe: 백엔드 분석 실패 (${err instanceof Error ? err.message : err}). 로컬 규칙 엔진으로 전환합니다.`,
      );
      const config = vscode.workspace.getConfiguration('vibesafe');
      await config.update('engine', 'rules', vscode.ConfigurationTarget.Global);
      analyzer = createAnalyzer();
      await analyzeDocument(doc);
    }
  }

  // 타이핑 시 debounce 후 재분석
  let timer: ReturnType<typeof setTimeout> | undefined;
  const debounceMs = () => vscode.workspace.getConfiguration('vibesafe').get<number>('debounceMs', 500);

  context.subscriptions.push(
    vscode.workspace.onDidChangeTextDocument((e) => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => analyzeDocument(e.document), debounceMs());
    }),
    vscode.window.onDidChangeActiveTextEditor((editor) => {
      if (editor) analyzeDocument(editor.document);
      else statusBar.setIdle();
    }),
    vscode.workspace.onDidChangeConfiguration((e) => {
      if (e.affectsConfiguration('vibesafe.engine') || e.affectsConfiguration('vibesafe.remoteEndpoint')) {
        analyzer = createAnalyzer();
        const editor = vscode.window.activeTextEditor;
        if (editor) analyzeDocument(editor.document);
      }
    }),
    vscode.commands.registerCommand('vibesafe.analyzeFile', () => {
      const editor = vscode.window.activeTextEditor;
      if (editor) analyzeDocument(editor.document);
    }),
    vscode.commands.registerCommand('vibesafe.showPanel', () => {
      vscode.commands.executeCommand('workbench.view.extension.vibesafe');
    }),
  );

  // 시작 시 열려 있는 파일 분석
  if (vscode.window.activeTextEditor) {
    analyzeDocument(vscode.window.activeTextEditor.document);
  }
}

export function deactivate(): void {
  // 정리할 리소스는 context.subscriptions가 자동 처리
}
